<?php
/**
 * Users Controller
 */
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../utils/Response.php';

function handleUsers(string $method, ?string $id = null) {
    requireRole(['Admin']);

    switch ($method) {
        case 'GET':
            if ($id) {
                $user = User::findById((int)$id);
                if (!$user) jsonError('Usuario no encontrado', 404);
                jsonSuccess($user);
            }
            jsonSuccess(User::getAll());
            break;

        case 'POST':
            $data = getJsonBody();
            $err = validateRequired($data, ['name', 'email', 'password', 'role']);
            if ($err) jsonError($err);

            // Check duplicate email
            if (User::findByEmail($data['email'])) {
                jsonError('Ya existe un usuario con ese email');
            }

            $newId = User::create($data);
            $user = User::findById($newId);
            jsonSuccess($user, 'Usuario creado', 201);
            break;

        case 'PUT':
            if (!$id) jsonError('ID requerido');
            $data = getJsonBody();
            User::update((int)$id, $data);
            $user = User::findById((int)$id);
            jsonSuccess($user, 'Usuario actualizado');
            break;

        case 'DELETE':
            if (!$id) jsonError('ID requerido');
            $result = User::delete((int)$id);
            if (!$result) jsonError('No se puede eliminar al último administrador');
            jsonSuccess(null, 'Usuario eliminado');
            break;

        default:
            jsonError('Método no permitido', 405);
    }
}
